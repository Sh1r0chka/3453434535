from django.test import TestCase
from unittest import skip
from django.test import LiveServerTestCase
from .models import Tovar
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By


class NameFunctionalTest(LiveServerTestCase):
    def setUp(self):
        self.selenium = webdriver.Edge()
        super().setUp()

    def tearDown(self):
        self.selenium.quit()
        super().tearDown()

    def test_product_list_functional(self):
        # Create test data
        Tovar.objects.create(
            tovarname="Велосипедный руль",
            tovartovartovarprice=7300,
            shipping="До 7 дней",
            category="Запчасти",
            tovardescrpt="Описание",
            tovarimage="{% static 'img/fortest/test1.jpg' %}"
        )
        Tovar.objects.create(
            tovarname="Велосипед Mechta Araba",
            tovartovartovarprice=1200000,
            shipping="До 3 дней",
            category="Горный велосипед",
            tovardescrpt="Описание",
            tovarimage="{% static 'img/fortest/test2.png' %}"
        )

        # Simulate user interactions using Selenium
        self.selenium.get(self.live_server_url)
        self.assertIn("Главная страница", self.selenium.title)
        names = self.selenium.find_elements(By.CLASS_NAME, "media")
        self.assertEqual(len(names), 2)
        self.assertEqual(names[0].text.split("\n")[0], "Велосипедный руль")
        self.assertEqual(names[1].text.split("\n")[0], "Велосипед Mechta Araba")

from unittest import skip
from django.test import TestCase, RequestFactory
from unittest.mock import Mock, patch
from main.views import index


class TovarListViewTest(TestCase):
    def setUp(self):
        self.factory = RequestFactory()

    def test_name_list_view(self):
        Tovar.objects.create(title='Велосипедный руль', tovartovarprice=7300)
        Tovar.objects.create(title='Велосипед Mechta Araba', tovartovarprice=1200000)

        request = self.factory.get('/index/')

        mock_queryset = Mock(spec=Tovar.objects.all())
        mock_queryset.return_value = [
            Mock(title='Велосипедный руль', tovartovarprice=7300),
            Mock(title='Велосипед Mechta Araba', tovartovarprice=1200000)
        ]

        with patch('main.views.Tovar.objects.all', mock_queryset):
            response = index(request)

        self.assertEqual(response.status_code, 200)

from django.test import TestCase
from main.models import Tovar

class TovarModelTest(TestCase):
    
    @classmethod
    def setUpTestData(cls):
        Tovar.objects.create(title='Велосипедный руль', tovartovarprice=7300,)

    def test_first_name_label(self):
        Tovar = Tovar.objects.get(id=1)
        field_label = Tovar._meta.get_field('tovarname').verbose_name
        self.assertEqual(field_label, 'Наименование')

    def test_phone_label(self):
        Tovar = Tovar.objects.get(id=1)
        field_label = Tovar._meta.get_field('tovardescrpt').verbose_name
        self.assertEqual(field_label, 'Описание товара')

    def test_surname_max_length(self):
        Tovar = Tovar.objects.get(id=1)
        max_length = Tovar._meta.get_field('tovarprice').max_length
        self.assertEqual(max_length, 50) 

from unittest import skip
from django.test import TestCase
from main.models import Tovar

class MyModelTest(TestCase):
    def setUp(self):
        self.object = Tovar.objects.create(title="Велосипед Mechta Araba", tovarprice=1200000)

    def test_str_representation(self):
        self.assertEqual(str(self.object), 'Велосипед Mechta Araba')

    def tearDown(self):
        pass

from unittest import skip
from django.test import TestCase
from django.urls import reverse


class SimpleTests(TestCase):
    def test_home_page_status_code(self):
        url = reverse('index')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_home_template_used(self):
        url = reverse('index')
        response = self.client.get(url)
        self.assertTemplateUsed(response, 'main/index.html')

from unittest import skip
from django.test import TransactionTestCase
from main.models import Tovar


class WidgetTransactionTestCase(TransactionTestCase):
    def test_widget_creation(self):
        Tovar.objects.create(title='Велосипед Mechta Araba', tovarprice=1200000)
        Tovar.objects.create(title='Консультация', tovarprice=0)
        self.assertEqual(Tovar.objects.count(), 2)
